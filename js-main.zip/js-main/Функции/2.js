"use strict mode"
for (let index = 1; index < 101; index++) {
    if (index <= 17) console.log(index, "ребёнок");
    else if (index <= 30) console.log(index, "молодой");
    else if (index <= 55) console.log(index, "зрелый");
    else console.log(index, "старый");
}