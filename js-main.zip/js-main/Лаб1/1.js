"use strict";
const x1 = -5,
  y1 = 8,
  x2 = 10,
  y2 = 5;
console.log(Math.abs(x2 - x1) * Math.abs(y2 - y1));
