"use strict mode"
for (let index = 0; index < 16; index++) {
    if (index % 2 === 0) {
        console.log(`Число ${index} чётное`);
    }
    else {
        console.log(`Число ${index} нечётное`);
    }
}